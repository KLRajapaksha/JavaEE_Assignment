package org.acme;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
class NativePetResourceIT extends PetResourceTest {

    // Execute the same tests but in native mode.
}