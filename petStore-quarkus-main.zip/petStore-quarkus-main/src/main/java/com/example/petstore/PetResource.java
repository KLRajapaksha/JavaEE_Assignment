package com.example.petstore;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.example.petstore.repo.PetRepo;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;

@Path("/v1/pets")
@Produces("application/json")
public class PetResource {

	@Inject
	PetRepo petRepo ;

	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "All Pets", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))) })
	@GET
	public Response getPets() {
		List<Pet> petArray = new ArrayList<Pet>();
		Pet newPet1 = new Pet();
		newPet1.setPetId(1);
		newPet1.setPetAge(3);
		newPet1.setPetName("Boola");
		newPet1.setPetType("Dog");

		Pet newPet2 = new Pet();
		newPet2.setPetId(2);
		newPet2.setPetAge(4);
		newPet2.setPetName("Sudda");
		newPet2.setPetType("Cat");

		Pet newPet3 = new Pet();
		newPet3.setPetId(3);
		newPet3.setPetAge(2);
		newPet3.setPetName("Peththappu");
		newPet3.setPetType("Bird");

		petArray.add(newPet1);
		petArray.add(newPet2);
		petArray.add(newPet3);
		return Response.ok(petArray).build();
	}

	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "Pet for id", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))),
			@APIResponse(responseCode = "404", description = "No Pet found for the id.") })
	@GET
	@Path("{petId}")
	public Response getPet(@PathParam("petId") int petId) {
		if (petId < 0) {
			return Response.status(Status.NOT_FOUND).build();
		}
		Pet newPet = new Pet();
		newPet.setPetId(petId);
		newPet.setPetAge(3);
		newPet.setPetName("Buula");
		newPet.setPetType("Dog");

		return Response.ok(newPet).build();
		
	}

	//search a pet with the given name to the api
	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "Search Pet by Name", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))) })
	@GET
	@Path("search/{petNameRQ}")
	public Response getPetByName(@PathParam("petNameRQ") String petName){
		List<Pet> petListRS = petRepo.findPetsByPetName(petName);
		return Response.ok(petListRS).build();
	}


	// change the pet type api
	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "change petType", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))) })
	@GET
	@Path("changePetType/{id}/{typeOfPet}")
	public Response changePetType(@PathParam("id") int id, @PathParam("typeOfPet") String typeOfPet){
		Optional<Pet> newPet = petRepo.findById(id);
		if(newPet.isPresent()){
			return Response.status(404).entity("Not found").build();
		} else{
			newPet.get().setPetType(typeOfPet);
			Pet newPet1 = petRepo.save(newPet.get());
			return Response.ok(newPet1).build();
		}

	}


	// delete a pet by the given pet type api
	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "Delete Pet by petType", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))) })
	@GET
	@Path("deletePetByPetType/{typeOfPet}")
	public Response deletePetByPetType(@PathParam("typeOfPet") String typeOfPet){

		petRepo.deletePetsByPetType(typeOfPet);
		return Response.ok().build();

	}


	// find a pet by the given pet type api
	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "find Pets by petType", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))) })
	@GET
	@Path("findPetsByPetType/{typeOfPet}")
	public Response findPetsByPetType(@PathParam("typeOfPet") String typeOfPet){

		List<Pet> petListRS = petRepo.findPetsByPetType(typeOfPet);
		return Response.ok(petListRS).build();

	}


	// Add a new pet api
	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "Add new pet", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))) })
	@POST
	@Path("addNewPet")
	public Response addNewPet(@RequestBody Pet petRQ){

		Pet petRS = petRepo.save(petRQ);
		return Response.ok(petRS).build();

	}


	// get all pets api
	@APIResponses(value = {
			@APIResponse(responseCode = "200", description = "get all pets", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(ref = "Pet"))) })
	@GET
	@Path("getAllPets")
	public Response getAllPets(){
		List<Pet> petList = petRepo.findAll();
		return Response.ok(petList).build();
	}


}
